import React, { useEffect, useState } from 'react';

function App() {
  const [moods, setMoods] = useState([]);
  const [note, setNote] = useState('');
  const [label, setLabel] = useState('Calm');
  const [color, setColor] = useState('#a3d8f4');

  useEffect(() => {
    // Fetch from backend later
    // fetch('http://localhost:5000/api/moods').then(r => r.json()).then(setMoods);
  }, []);

  function handleSubmit(e) {
    e.preventDefault();
    const newMood = { note, label, color, date: new Date().toISOString() };
    setMoods(prev => [newMood, ...prev]);
    setNote('');
  }

  return (
    <div style={{ padding: 20, background: '#f7fbff', minHeight: '100vh' }}>
      <h1>MindHue</h1>
      <form onSubmit={handleSubmit}>
        <label>Color</label><br />
        <input type="color" value={color} onChange={e => setColor(e.target.value)} /><br /><br />

        <label>Mood</label><br />
        <select value={label} onChange={e => setLabel(e.target.value)}>
          <option>Calm</option>
          <option>Content</option>
          <option>Stressed</option>
          <option>Sad</option>
          <option>Angry</option>
          <option>Tired</option>
          <option>Hopeful</option>
        </select><br /><br />

        <label>Note</label><br />
        <textarea
          value={note}
          onChange={e => setNote(e.target.value)}
          placeholder="Short reflection..."
          required
        />
        <br /><br />
        <button type="submit">Save</button>
      </form>

      <hr />
      <ul>
        {moods.map((m, i) => (
          <li key={i} style={{ background: m.color, margin: '10px 0', padding: 10 }}>
            <strong>{m.label}</strong>: {m.note}
            <br />
            <small>{new Date(m.date).toLocaleString()}</small>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
